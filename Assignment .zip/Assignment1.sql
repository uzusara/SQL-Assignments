create database mydatabase;
use mydatabase;
create table customer(
id int Primary key,FirstName nvarchar(40) NOT NULL,
LastName nvarchar(40),
City nvarchar(40),
Country nvarchar(40),
Phone nvarchar(20));

create table Orderr(
id int Primary key,OrderDate datetime NOT NULL,
OrderNumber nvarchar(10),
Customerid int Foreign key References Customer(id),
TotalAmount decimal(12,2));

Alter table Orderr
Drop column OrderDate;

Alter table Orderr
Add OrderDate DateTime NOT NULL;

create table Product(
id int Primary key,ProductName nvarchar(50),
UnitPrice decimal(12,2),
Package nvarchar(30),
IsDiscontinued bit);

create table OrderItem(
id int Primary key,OrderId int Foreign key References Orderr(id),
ProductId int Foreign key References Product(id),
UnitPrice decimal(12,2),
Quantity int);


--Insert Records--

INSERT INTO Customer(id,FirstName,LastName,City,Country,Phone)
VALUES(123,'Mark','Suz','Bang','India',66666),(124,'Sakr','Maz','Rag','India',55555),(125,'Dur','jum','Rus','Arab',66666),
(126,'Sarkar','Maria','Russ','Iraq',77777),(127,'Sudeep','Mischelle','Kolkatta','Iraq',88888);

Select * from Customer;


INSERT INTO Orderr(id,OrderDate,OrderNumber,Customerid,TotalAmount)
VALUES(121,09/03/2022,2,123,210),(122,09/04/2022,3,124,210),(123,09/05/2022,4,125,212),(124,09/03/2022,2,126,220),
(125,09/06/2022,5,127,510);

Select * from Orderr;

INSERT INTO Product(id,ProductName,UnitPrice,Package,IsDiscontinued)
VALUES(101,'Pro1',48,'Yes',0),(102,'Pro2',49,'Yes',1),(103,'Pro3',50,'No',0),(104,'Pro4',48,'Yes',NULL),
(105,'Pro5',48,'No',0);

Select * from Product;

INSERT INTO OrderItem(id,OrderId,ProductId,UnitPrice,Quantity)
VALUES(1,121,101,48,2),(2,122,102,49,2),(3,123,103,50,2),(4,124,104,48,2),(5,125,105,48,2);

Select * from OrderItem;



select Country from Customer
where Country LIKE 'A%' or Country LIKE 'I%';


select FirstName from Customer 
WHERE FirstName LIKE '__i%';

